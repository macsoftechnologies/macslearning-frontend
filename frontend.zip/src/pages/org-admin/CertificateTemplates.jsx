import { useState, useEffect, useRef } from 'react';
import { Plus, Image as ImageIcon, Type, Save, Trash2, X } from 'lucide-react';
import toast from 'react-hot-toast';
import * as api from '../../api/certificates';
import DataTable from '../../components/ui/DataTable';
import Button from '../../components/ui/Button';
import Modal from '../../components/ui/Modal';
import Input, { Field, Select } from '../../components/ui/Input';
import FileUploader from '../../components/ui/FileUploader';
import PageLoader from '../../components/ui/PageLoader';

const DUMMY_DATA = {
  student_name: 'John Doe',
  course_title: 'Advanced Web Development',
  completion_date: new Date().toLocaleDateString(),
  certificate_number: 'CERT-ABCD1234'
};

// A simple draggable element component
function DraggableElement({ field, index, onUpdate, onRemove, scale = 1 }) {
  const [isDragging, setIsDragging] = useState(false);
  const dragStart = useRef({ x: 0, y: 0, initX: 0, initY: 0 });

  const handleMouseDown = (e) => {
    setIsDragging(true);
    dragStart.current = {
      x: e.clientX,
      y: e.clientY,
      initX: field.x,
      initY: field.y
    };
  };

  useEffect(() => {
    if (!isDragging) return;
    
    const handleMouseMove = (e) => {
      const dx = (e.clientX - dragStart.current.x) / scale;
      const dy = (e.clientY - dragStart.current.y) / scale;
      onUpdate(index, { 
        ...field, 
        x: Math.round(dragStart.current.initX + dx),
        y: Math.round(dragStart.current.initY + dy)
      });
    };
    
    const handleMouseUp = () => setIsDragging(false);
    
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, field, index, onUpdate, scale]);

  const style = {
    position: 'absolute',
    left: `${field.x * scale}px`,
    top: `${field.y * scale}px`,
    cursor: isDragging ? 'grabbing' : 'grab',
    userSelect: 'none',
    border: isDragging ? '2px dashed var(--color-primary-500)' : '2px dashed transparent',
    padding: '4px',
    transform: 'translate(-50%, -50%)', // Center origin
  };

  if (field.type === 'text') {
    return (
      <div style={style} onMouseDown={handleMouseDown}>
        <div style={{
          fontSize: `${(field.fontSize || 16) * scale}px`,
          color: field.color || '#000000',
          fontFamily: field.fontFamily || 'Helvetica',
          fontWeight: 600,
          whiteSpace: 'nowrap',
          background: 'rgba(255, 255, 255, 0.7)',
          padding: '2px 8px',
          borderRadius: '4px'
        }}>
          {field.variable ? (DUMMY_DATA[field.variable] || `[${field.variable}]`) : field.value || 'Text Field'}
        </div>
        <button 
          onClick={(e) => { e.stopPropagation(); onRemove(index); }}
          style={{ position: 'absolute', top: '-10px', right: '-10px', background: 'red', color: 'white', borderRadius: '50%', border: 'none', cursor: 'pointer', width: '20px', height: '20px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
        >
          <X size={12} />
        </button>
      </div>
    );
  }

  if (field.type === 'image') {
    return (
      <div style={style} onMouseDown={handleMouseDown}>
        <img 
          src={field.url.startsWith('http') ? field.url : import.meta.env.VITE_STATIC_BASE_URL + field.url} 
          alt="embedded" 
          style={{ 
            width: `${(field.width || 100) * scale}px`, 
            height: `${(field.height || 50) * scale}px`, 
            objectFit: 'contain',
            background: 'rgba(255, 255, 255, 0.7)',
            padding: '4px',
            borderRadius: '4px'
          }} 
          draggable={false}
        />
        <button 
          onClick={(e) => { e.stopPropagation(); onRemove(index); }}
          style={{ position: 'absolute', top: '-10px', right: '-10px', background: 'red', color: 'white', borderRadius: '50%', border: 'none', cursor: 'pointer', width: '20px', height: '20px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
        >
          <X size={12} />
        </button>
      </div>
    );
  }

  return null;
}

export default function CertificateTemplates() {
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [previewTemplate, setPreviewTemplate] = useState(null);
  
  const [isBuilderOpen, setIsBuilderOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  
  // Builder State
  const [templateName, setTemplateName] = useState('');
  const [bgType, setBgType] = useState('BLANK');
  const [bgUrl, setBgUrl] = useState('');
  const [fields, setFields] = useState([]);
  
  // Real PDF A4 Landscape Dimensions
  const A4_WIDTH = 842;
  const A4_HEIGHT = 595;
  
  // Canvas Scaling for Display
  const canvasContainerRef = useRef(null);
  const [scale, setScale] = useState(1);

  const load = () => {
    setLoading(true);
    api.listTemplates()
      .then(res => setTemplates(res.data?.data || []))
      .catch(() => toast.error('Failed to load templates'))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
  }, []);

  useEffect(() => {
    if (isBuilderOpen && canvasContainerRef.current) {
      const updateScale = () => {
        const containerWidth = canvasContainerRef.current.clientWidth;
        // Leave some padding
        const newScale = Math.min((containerWidth - 40) / A4_WIDTH, 1);
        setScale(newScale);
      };
      updateScale();
      window.addEventListener('resize', updateScale);
      return () => window.removeEventListener('resize', updateScale);
    }
  }, [isBuilderOpen]);

  const [editId, setEditId] = useState(null);

  const openBuilder = (template = null) => {
    if (template) {
      setEditId(template._id || template.id);
      setTemplateName(template.name);
      setBgType(template.backgroundType || 'BLANK');
      setBgUrl(template.backgroundImageUrl || '');
      setFields(template.fields || []);
    } else {
      setEditId(null);
      setTemplateName('');
      setBgType('IMAGE');
      setBgUrl('/uploads/default_cert_bg.png');
      setFields([
        { 
          type: 'text', 
          value: 'Certificate of Completion', 
          x: A4_WIDTH / 2, 
          y: 120, 
          fontSize: 48, 
          color: '#000000', 
          fontFamily: 'Helvetica' 
        },
        { 
          type: 'text', 
          variable: 'student_name', 
          x: A4_WIDTH / 2, 
          y: 280, 
          fontSize: 40, 
          color: '#1a242f', 
          fontFamily: 'Helvetica' 
        },
        { 
          type: 'text', 
          value: 'has successfully completed the course', 
          x: A4_WIDTH / 2, 
          y: 340, 
          fontSize: 20, 
          color: '#000000', 
          fontFamily: 'Helvetica' 
        },
        { 
          type: 'text', 
          variable: 'course_title', 
          x: A4_WIDTH / 2, 
          y: 400, 
          fontSize: 24, 
          color: '#2980b9', 
          fontFamily: 'Helvetica' 
        },
        { 
          type: 'text', 
          variable: 'certificate_number', 
          x: A4_WIDTH / 2, 
          y: 500, 
          fontSize: 14, 
          color: '#7f8c8d', 
          fontFamily: 'Helvetica' 
        }
      ]);
    }
    setIsBuilderOpen(true);
  };

  const addTextField = () => {
    setFields([...fields, { 
      type: 'text', 
      variable: 'student_name', 
      x: A4_WIDTH / 2, 
      y: A4_HEIGHT / 2, 
      fontSize: 32, 
      color: '#000000', 
      fontFamily: 'Helvetica' 
    }]);
  };
  
  const addSignatureField = (uploadedUrl) => {
    setFields([...fields, { 
      type: 'image', 
      url: uploadedUrl, 
      x: A4_WIDTH / 2 + 200, 
      y: A4_HEIGHT - 100, 
      width: 150, 
      height: 60 
    }]);
  };

  const addStampField = (uploadedUrl) => {
    setFields([...fields, { 
      type: 'image', 
      url: uploadedUrl, 
      x: A4_WIDTH / 2 - 200, 
      y: A4_HEIGHT - 100, 
      width: 120, 
      height: 120 
    }]);
  };

  const updateField = (index, newField) => {
    const updated = [...fields];
    updated[index] = newField;
    setFields(updated);
  };

  const removeField = (index) => {
    setFields(fields.filter((_, i) => i !== index));
  };

  const handleSave = async () => {
    if (!templateName) return toast.error('Please enter a template name');
    setSaving(true);
    try {
      const payload = {
        name: templateName,
        backgroundType: bgType,
        backgroundImageUrl: bgUrl,
        fields
      };
      if (editId) {
        await api.updateTemplate(editId, payload);
        toast.success('Template updated successfully');
      } else {
        await api.createTemplate(payload);
        toast.success('Template saved successfully');
      }
      setIsBuilderOpen(false);
      load();
    } catch (err) {
      toast.error('Failed to save template');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <PageLoader />;

  return (
    <div style={{ padding: 'var(--sp-6)' }}>
      <div className="row" style={{ justifyContent: 'space-between', marginBottom: 'var(--sp-6)' }}>
        <div>
          <h1 style={{ fontSize: 'var(--fs-2xl)', fontWeight: 700 }}>Certificate Templates</h1>
          <p className="text-muted">Design and manage certificate templates for your organization.</p>
        </div>
        <Button icon={Plus} onClick={() => openBuilder()}>Create Template</Button>
      </div>

      <DataTable
        emptyLabel="No templates created yet."
        columns={[
          { key: 'name', header: 'Template Name', render: (r) => r.name },
          { key: 'bgType', header: 'Background', render: (r) => r.backgroundType },
          { key: 'fields', header: 'Dynamic Fields', render: (r) => r.fields?.length || 0 },
          { key: 'createdAt', header: 'Created At', render: (r) => new Date(r.createdAt).toLocaleDateString() },
          {
            key: 'actions', header: 'Actions', render: (r) => (
              <div className="row" style={{ gap: '8px' }}>
                <Button size="sm" variant="ghost" onClick={() => setPreviewTemplate(r)}>Preview</Button>
                <Button size="sm" variant="outline" onClick={() => openBuilder(r)}>Edit Template</Button>
              </div>
            )
          }
        ]}
        rows={templates}
      />

      <Modal open={!!previewTemplate} onClose={() => setPreviewTemplate(null)} title="Template Preview" width={950}>
        <div style={{ padding: '24px', display: 'flex', justifyContent: 'center', background: 'var(--color-paper-50)' }}>
          <div style={{
            width: `${A4_WIDTH * 1}px`,
            height: `${A4_HEIGHT * 1}px`,
            background: previewTemplate?.backgroundType === 'BLANK' ? '#ffffff' : (previewTemplate?.backgroundImageUrl ? `url(${previewTemplate.backgroundImageUrl.startsWith('http') ? previewTemplate.backgroundImageUrl : import.meta.env.VITE_STATIC_BASE_URL + previewTemplate.backgroundImageUrl})` : '#ffffff'),
            backgroundSize: '100% 100%',
            position: 'relative',
            boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1)',
            overflow: 'hidden',
            transform: 'scale(0.9)',
            transformOrigin: 'top center'
          }}>
            {(previewTemplate?.fields || []).map((f, i) => {
              if (f.type === 'text') {
                return (
                  <div key={i} style={{
                    position: 'absolute',
                    left: `${f.x}px`,
                    top: `${f.y}px`,
                    transform: 'translate(-50%, -50%)',
                    fontSize: `${f.fontSize || 16}px`,
                    color: f.color || '#000000',
                    fontFamily: f.fontFamily || 'Helvetica',
                    fontWeight: 600,
                    whiteSpace: 'nowrap'
                  }}>
                    {f.variable ? (DUMMY_DATA[f.variable] || `[${f.variable}]`) : f.value || 'Text Field'}
                  </div>
                );
              }
              if (f.type === 'image') {
                return (
                  <div key={i} style={{
                    position: 'absolute',
                    left: `${f.x}px`,
                    top: `${f.y}px`,
                    transform: 'translate(-50%, -50%)'
                  }}>
                    <img 
                      src={f.url.startsWith('http') ? f.url : import.meta.env.VITE_STATIC_BASE_URL + f.url} 
                      alt="embedded" 
                      style={{ 
                        width: `${f.width || 100}px`, 
                        height: `${f.height || 50}px`, 
                        objectFit: 'contain'
                      }} 
                    />
                  </div>
                );
              }
              return null;
            })}
          </div>
        </div>
        <div className="modal-panel__foot" style={{ margin: '0 -24px -24px', padding: '16px 24px', justifyContent: 'flex-end' }}>
          <Button variant="outline" onClick={() => setPreviewTemplate(null)}>Close Preview</Button>
        </div>
      </Modal>

      <Modal open={isBuilderOpen} onClose={() => setIsBuilderOpen(false)} title="Certificate Template Builder" width={1100}>
        <div style={{ display: 'flex', gap: '24px', height: '600px' }}>
          
          {/* Left Panel: Tools & Properties */}
          <div style={{ width: '300px', flexShrink: 0, display: 'flex', flexDirection: 'column', gap: '16px', overflowY: 'auto', paddingRight: '8px' }}>
            <Field label="Template Name" required>
              <Input value={templateName} onChange={e => setTemplateName(e.target.value)} placeholder="e.g. Standard Excellence Award" />
            </Field>

            <div style={{ borderTop: '1px solid var(--border-subtle)', margin: '8px 0' }} />
            
            <h3 style={{ fontSize: '14px', fontWeight: 600 }}>Background Settings</h3>
            <div className="row" style={{ gap: '8px' }}>
              <Button size="sm" variant={bgType === 'BLANK' ? 'primary' : 'outline'} onClick={() => setBgType('BLANK')}>Blank Canvas</Button>
              <Button size="sm" variant={bgType === 'IMAGE' ? 'primary' : 'outline'} onClick={() => setBgType('IMAGE')}>Upload BG</Button>
            </div>
            
            {bgType === 'IMAGE' && (
              <Field label="Upload Background Image (A4 Landscape, PNG/JPG)">
                <FileUploader 
                  onUploaded={(url) => setBgUrl(url)}
                />
              </Field>
            )}

            <div style={{ borderTop: '1px solid var(--border-subtle)', margin: '8px 0' }} />
            
            <h3 style={{ fontSize: '14px', fontWeight: 600 }}>Add Elements</h3>
            <div className="stack" style={{ gap: '8px' }}>
              <Button size="sm" variant="outline" icon={Type} onClick={addTextField}>Add Text Field</Button>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
                <div style={{ padding: '8px', background: 'var(--color-paper-50)', borderRadius: '8px', border: '1px dashed var(--border-subtle)', textAlign: 'center' }}>
                  <p style={{ fontSize: '11px', marginBottom: '8px', fontWeight: 600 }}>Add Signature</p>
                  <FileUploader onUploaded={addSignatureField} />
                </div>
                <div style={{ padding: '8px', background: 'var(--color-paper-50)', borderRadius: '8px', border: '1px dashed var(--border-subtle)', textAlign: 'center' }}>
                  <p style={{ fontSize: '11px', marginBottom: '8px', fontWeight: 600 }}>Add Stamp / Seal</p>
                  <FileUploader onUploaded={addStampField} />
                </div>
              </div>
            </div>

            <div style={{ borderTop: '1px solid var(--border-subtle)', margin: '8px 0' }} />
            
            <h3 style={{ fontSize: '14px', fontWeight: 600 }}>Layer Properties</h3>
            {fields.map((f, i) => (
              <div key={i} style={{ padding: '12px', background: 'var(--color-surface)', borderRadius: '8px', border: '1px solid var(--border-subtle)' }}>
                <div className="row" style={{ justifyContent: 'space-between', marginBottom: '8px' }}>
                  <span style={{ fontSize: '12px', fontWeight: 600, textTransform: 'uppercase' }}>{f.type} Element</span>
                  <button onClick={() => removeField(i)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--danger)' }}><Trash2 size={14}/></button>
                </div>
                
                {f.type === 'text' && (
                  <div className="stack" style={{ gap: '8px' }}>
                    <Select 
                      value={f.variable || ''} 
                      onChange={e => updateField(i, { ...f, variable: e.target.value, value: '' })}
                    >
                      <option value="">-- Custom Text --</option>
                      <option value="student_name">[Student Name]</option>
                      <option value="course_title">[Course Title]</option>
                      <option value="completion_date">[Completion Date]</option>
                      <option value="certificate_number">[Certificate Number]</option>
                    </Select>
                    
                    {!f.variable && (
                      <Input 
                        placeholder="Static Text" 
                        value={f.value || ''} 
                        onChange={e => updateField(i, { ...f, value: e.target.value })} 
                      />
                    )}
                    
                    <div className="row" style={{ gap: '8px' }}>
                      <Input 
                        type="number" 
                        placeholder="Size" 
                        value={f.fontSize || 16} 
                        onChange={e => updateField(i, { ...f, fontSize: parseInt(e.target.value) })} 
                      />
                      <Input 
                        type="color" 
                        value={f.color || '#000000'} 
                        onChange={e => updateField(i, { ...f, color: e.target.value })} 
                      />
                    </div>
                  </div>
                )}
                
                {f.type === 'image' && (
                  <div className="row" style={{ gap: '8px' }}>
                    <Input 
                      type="number" 
                      placeholder="Width" 
                      value={f.width || 100} 
                      onChange={e => updateField(i, { ...f, width: parseInt(e.target.value) })} 
                    />
                    <Input 
                      type="number" 
                      placeholder="Height" 
                      value={f.height || 50} 
                      onChange={e => updateField(i, { ...f, height: parseInt(e.target.value) })} 
                    />
                  </div>
                )}
              </div>
            ))}

          </div>

          {/* Right Panel: Canvas */}
          <div ref={canvasContainerRef} style={{ flex: 1, background: 'var(--color-paper-50)', display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: '8px', overflow: 'hidden', position: 'relative', border: '1px solid var(--border-subtle)' }}>
            
            <div style={{
              width: `${A4_WIDTH * scale}px`,
              height: `${A4_HEIGHT * scale}px`,
              background: bgType === 'BLANK' ? '#ffffff' : (bgUrl ? `url(${bgUrl.startsWith('http') ? bgUrl : import.meta.env.VITE_STATIC_BASE_URL + bgUrl})` : '#ffffff'),
              backgroundSize: '100% 100%',
              position: 'relative',
              boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1)',
              overflow: 'hidden'
            }}>
              {/* Reference Grid lines */}
              <div style={{ position: 'absolute', top: '50%', left: 0, right: 0, borderTop: '1px dashed rgba(0,0,0,0.1)' }} />
              <div style={{ position: 'absolute', left: '50%', top: 0, bottom: 0, borderLeft: '1px dashed rgba(0,0,0,0.1)' }} />

              {fields.map((f, i) => (
                <DraggableElement 
                  key={i} 
                  field={f} 
                  index={i} 
                  onUpdate={updateField} 
                  onRemove={removeField} 
                  scale={scale} 
                />
              ))}
            </div>

          </div>
        </div>

        <div className="modal-panel__foot" style={{ margin: '24px -24px -24px', padding: '16px 24px', display: 'flex', justifyContent: 'flex-end', gap: '12px' }}>
          <Button variant="outline" onClick={() => setIsBuilderOpen(false)}>Cancel</Button>
          <Button icon={Save} onClick={handleSave} loading={saving}>Save Template</Button>
        </div>
      </Modal>
    </div>
  );
}
